import React from "react";

import "./SavedMovies.css";
import NavMenu from "../NavMenu/NavMenu";
import SearchForm from "../Movies/SearchForm/SearchForm";
import MoviesCard from "../Movies/MoviesCard/MoviesCard";
import BurgerMenu from "../BurgerMenu/BurgerMenu";
import Footer from "../Footer/Footer";

import { savedMoviesDB } from "../../utils/constants";
// import Movies from "../Movies/Movies";

export default function SavedMovies({
  setMenuOpened,
  burgerOpened,
  burgerClosed,
}) {
  return (
    <section className="saved-movies">
      <NavMenu setIsOpened={setMenuOpened} />
      <SearchForm />
      <ul className="saved-movies__table">
        {savedMoviesDB.map((movie) => {
          return (
            <MoviesCard
              id={movie.id}
              nameRU={movie.nameRU}
              duration={movie.duration}
              image={movie.image}
              block="saved"
            />
          );
        })}
      </ul>
      <BurgerMenu isOpen={burgerOpened} burgerClosed={burgerClosed} />
      <Footer />
    </section>
  );
}
