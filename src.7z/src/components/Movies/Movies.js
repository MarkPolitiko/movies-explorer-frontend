import React from "react";

import "./Movies.css";
import SearchForm from "./SearchForm/SearchForm";
import Footer from "../Footer/Footer";
import MoviesCard from "./MoviesCard/MoviesCard";
import { moviesDB } from "../../utils/constants";
import NavMenu from "../NavMenu/NavMenu";
import BurgerMenu from "../BurgerMenu/BurgerMenu";


export default function Movies({ setMenuOpened, burgerOpened, burgerClosed }) {
  return (
    <section className="movies">
      <NavMenu setIsOpened={setMenuOpened} />
      <SearchForm />
      <ul className="movies__table">
        {moviesDB.map((movie) => {
          return (
            <MoviesCard
              id={movie.id}
              nameRU={movie.nameRU}
              duration={movie.duration}
              image={movie.image}
              block="general"
            />
          );
        })}
      </ul>
      <button type="button" className="button__more" aria-label="Еще фильмы">
        Ещё
      </button>
      <BurgerMenu isOpen={burgerOpened} burgerClosed={burgerClosed} />
      <Footer />
    </section>
  );
}
