import React from "react";
import { Link } from "react-router-dom";

import "./BurgerMenu.css";

export default function BurgerMenu({ isOpen, burgerClosed }) {
  return (
    <>
      <div className={isOpen ? "burger-menu" : "burger-menu closed"}>
        <div className="burger-menu__container">
          <div className="burger-menu__shadow"></div>
          <nav className="burger-menu__nav-container">
            <button
              className="burger-menu__close-button"
              type="button"
              area-label="Закрыть меню"
              onClick={burgerClosed}
            />
            <ul className="burger-menu__elements">
              <li className="burger-menu__element" onClick={burgerClosed}>
                <Link to="/">Главная</Link>
              </li>
              <li className="burger-menu__element" onClick={burgerClosed}>
                <Link to="/movies">Фильмы</Link>
              </li>
              <li className="burger-menu__element" onClick={burgerClosed}>
                <Link to="/saved-movies">Сохраненные фильмы</Link>
              </li>
            </ul>
            <div className="burger-menu__profile-element">
              <Link to="/profile">Аккаунт</Link>
            </div>
          </nav>
        </div>
      </div>
    </>
  );
}
