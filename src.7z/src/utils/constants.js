export const moviesDB = [
  {
    id: 1,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design1_1.png",
    saved: false,
  },
  {
    id: 2,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design2.png",
    saved: false,
  },
  {
    id: 3,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design3.png",
    saved: true,
  },
  {
    id: 4,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design4.png",
    saved: false,
  },
  {
    id: 5,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design5.png",
    saved: true,
  },
  {
    id: 6,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design6.png",
    saved: false,
  },
  {
    id: 7,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design7.png",
    saved: false,
  },
  {
    id: 8,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design8.png",
    saved: false,
  },
  {
    id: 9,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design9.png",
    saved: false,
  },
  {
    id: 10,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design10.png",
    saved: true,
  },
  {
    id: 11,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design11.png",
    saved: false,
  },
  {
    id: 12,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design12.png",
    saved: false,
  }
];

export const savedMoviesDB = [
  {
    id: 3,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design3.png",
  },
  {
    id: 5,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design5.png",
  },
  {
    id: 10,
    nameRU: "33 слова о дизайне",
    duration: "1ч 47м",
    image: "https://www.linkpicture.com/q/design10.png",
  }
];
